const dbConfig = { 
    user : "java", 
    password : "1234",
    connectString : "localhost:1521/xe" 
}
module.exports = dbConfig;
    
    