const index = (req, res) => {
    res.render("session/index");
}
const setSession = (req, res) => {
    req.session.name = "홍길동";
    req.session.age = 20;
    res.render("session/set_session");
}
const getSession = (req, res) => {
    const sessionValue = { 
        name : req.session.name,
        age : req.session.age
    }
    res.render("session/get_session", sessionValue );
}
const delSession = (req, res) => {
    //delete req.session.name;
    req.session.destroy();
    res.render("session/del_session");
}
const login = (req, res) => {
    res.render("session/login", { username : req.session.username });
}
// http://localhost:3000/session/loginCheck

const db = require("../../db/session_mem");
const loginCheck = (req, res) => {
    const member = db.filter( 
        (mem) => mem.id === req.body.id && mem.pwd === req.body['pwd'] )
    console.log( "member : ", member);
    if( member.length != 0 ){
        req.session.username = member[0].id;
        req.session.nick = member[0].nick;
        req.session.save( ()=>{
            res.redirect("/session/success")
        } )
    }else{
        msg = scriptMsg("로그인 실패", "/session/login");
        res.send( msg );
    }
}
const loginCheck1 = (req, res) =>{
    console.log( req.body )
    console.log( req.body.id )
    console.log( req.body['pwd'] )
    let msg = "";
    const DBId = "aaa", DBPwd = "aaa", DBNick = "홍길동";
    if( DBId === req.body.id && DBPwd === req.body['pwd'] ){
        req.session.username = DBId;
        req.session.nick = DBNick;
        
        req.session.save( ()=>{
            res.redirect("/session/success")
        } )
        
       // return
       //msg = scriptMsg("로그인 성공", "/session/success");
    }
    else{
        msg = scriptMsg("로그인 실패", "/session/login");
        res.send( msg );
    }
    
    /*
    `<script>
        alert("로그인 실패");
        location.href="/session/login";
    </script>`;
    */
}
const scriptMsg = ( sMsg, sUrl ) => {
      return  `<script>
        alert("${sMsg}");
        location.href="${sUrl}";
    </script>`;
}
const success =  (req, res) => {
    //const DBId = "aaa", DBPwd = "aaa", DBNick = "홍길동";
    //req.session.username = DBId;
    //req.session.nick = DBNick;
    console.log("req.session.username : ",  req.session.username );
    if( req.session.username )
        return res.render("session/success", { nick : req.session.nick })
    let msg = scriptMsg("로그인 먼저하세요", "/session/login");
    /*
    `<script>
        alert("로그인 먼저하세요");
        location.href="/session/login";
    </script>`;
    */
    res.send( msg );
}
const logout = (req, res)=>{
    req.session.destroy( ()=>{
        console.log("모든 세션을 만료합니다");
       
    } );
    res.redirect("/session/login")
}
module.exports = {logout, loginCheck,  success,
    login, delSession, setSession, getSession, index };