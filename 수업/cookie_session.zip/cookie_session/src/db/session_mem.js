const users = [
    {id:"aaa", pwd:"aaa",nick : "a홍길동"},
    {id:"bbb", pwd:"bbb",nick : "b홍길동"},
    {id:"ccc", pwd:"ccc",nick : "c홍길동"},
]
module.exports = users;