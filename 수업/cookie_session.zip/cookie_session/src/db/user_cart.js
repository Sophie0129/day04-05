let cart = [
    {goods_id : 1 , title : "장난감", price : 5000},
    {goods_id : 2 , title : "컴퓨터", price : 100000},
    {goods_id : 3 , title : "자동차", price : 2000},
];
module.exports = cart;