const ser = require("../../service/member/member_service");
const login = (req, res) =>{
    res.render("member/login",{username : req.session.username});
}
const loginCheck = async (req, res) =>{
    const msgPack = await ser.loginCheck( req.body );
    if( msgPack.result === 0){
        req.session.username = req.body.id;
    }
    res.send( msgPack.msg );
}
const logout = (req, res) =>{
    req.session.destroy();
    res.clearCookie('isLogin');
    res.redirect("/");
}
const memberList = async (req, res) =>{
    const list = await ser.memberList();
    res.render("member/list",{ list : list });
}
    
module.exports = {memberList, logout, login , loginCheck };

