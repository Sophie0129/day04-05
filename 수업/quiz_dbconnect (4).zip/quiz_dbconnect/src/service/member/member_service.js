const memberDAO = require("../../database/member/member_dao");
const loginCheck = async ( body )=>{
    let member = await memberDAO.getMember( body.id );
    let msg="", url="", msgPack = {};
    if(member.rows.length == 1){
        member = member.rows[0];
        if( member.PWD === body.pwd ){
            msg = `${member.NAME}님 환영합니다^^`;
            url = "/";
            msgPack.result = 0;
        }else{
            msg = "비밀번호가 틀렸습니다!!!";
            url = '/member/login';
            msgPack.result = 1;
        }
    }else{
        msg = "존재하지 않는 아이디입니다!!";
        url = "/member/login";
        msgPack.result = 1;
    }
    msgPack.msg = getMessage(msg, url);
    return msgPack;
};
const  getMessage = (msg, url) =>{
    return `<script>alert('${msg}'); location.href="${url}";</script>`;
}
const memberList = () =>{
    return memberDAO.memberList();
}
    
module.exports = { memberList, loginCheck };
