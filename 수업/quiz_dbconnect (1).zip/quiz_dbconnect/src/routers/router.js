module.exports = (app)=>{
    const memberRouter = require("./member/member_router");
    app.use("/member", memberRouter );

    const router = require("express").Router();
    router.get("/", (req, res)=>{
        //res.send("connect test");
        res.render("index");
    })
    return router;
}

