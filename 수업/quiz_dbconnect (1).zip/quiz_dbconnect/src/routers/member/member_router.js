const router = require("express").Router();
const memberCtrl = require("../../controller/member/member_ctrl");
router.get("/login", memberCtrl.login );
module.exports = router;
