const login = (req, res) =>{
    res.render("member/login");
}
module.exports = { login };
    